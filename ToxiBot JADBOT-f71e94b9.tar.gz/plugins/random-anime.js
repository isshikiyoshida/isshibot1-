import axios from "axios"
let handler = async (m, {command, conn}) => {
if (command == 'akira') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/akira?apikey=APIKEY`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}
if (command == 'akiyama') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/akiyama?apikey=APIKEY`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}
if (command == 'anna') {
let haha = await conn.getFile(`https://api.zeeoneofc.xyz/api/anime/anna?apikey=5Cd8U3tG`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}
if (command == 'asuna') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/asuna?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}
if (command == 'ayuzawa') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/ayuzawa?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}    
if (command == 'boruto') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/boruto?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}
if (command == 'chiho') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/chiho?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}     
if (command == 'chitoge') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/chitoge?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}
if (command == 'deidara') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/deidara?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}
if (command == 'erza') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/erza?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}    
if (command == 'elaina') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/elaina?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}    
if (command == 'eba') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/eba?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'emilia') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/emilia?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'hestia') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/hestia?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}
if (command == 'hinata') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/hinata?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'inori') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/inori?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'isuzu') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/isuzu?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}     
if (command == 'itachi') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/itachi?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'itori') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/itori?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'kaga') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/kaga?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}
if (command == 'kagura') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/kagura?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'kaori') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/kaori?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'keneki') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/keneki?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)} 
if (command == 'kotori') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/kotori?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'kurumi') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/kurumi?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'madara') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/madara?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'mikasa') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/mikasa?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'miku') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/miku?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'minato') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/minato?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)} 
if (command == 'naruto') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/naruto?apikey=APIKEY`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}    
if (command == 'nezuko') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/nezuko?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'sagiri') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/sagiri?apikey=APIKEY`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}    
if (command == 'sasuke') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/sasuke?apikey=APIKEY`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)} 
if (command == 'sakura') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/wallpaper/sakura?apikey=APIKEY`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}  
if (command == 'cosplay') {
let haha = await conn.getFile(`https://api-reysekha.herokuapp.com/api/random/cosplay?apikey=apirey`)
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha.data, [['🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄', `/${command}`]], m)}     
}
handler.command = handler.help = ['akira', 'akiyama', 'anna', 'asuna', 'ayuzawa', 'boruto', 'chiho', 'chitoge', 'deidara', 'erza', 'elaina', 'eba', 'emilia', 'hestia', 'hinata', 'inori', 'isuzu', 'itachi', 'itori', 'kaga', 'kagura', 'kaori', 'keneki', 'kotori', 'kurumi', 'madara', 'mikasa', 'miku', 'minato', 'naruto', 'nezuko', 'sagiri', 'sasuke', 'sakura', 'cosplay']
handler.tags = ['anime']
export default handler
